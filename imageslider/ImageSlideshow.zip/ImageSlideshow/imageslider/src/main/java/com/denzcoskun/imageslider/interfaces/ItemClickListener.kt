package com.denzcoskun.imageslider.interfaces

interface ItemClickListener {
    fun onItemSelected(position: Int)
}